import React from "react";

function Header() {
  return (
    <header>
      <h1>
        {" "}
        <i> QUOTES </i>{" "}
      </h1>
    </header>
  );
}

export default Header;
