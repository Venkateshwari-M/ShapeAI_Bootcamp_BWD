import React from "react";
var cur_yr = new Date().getFullYear();

function Footer() {
  return (
    <footer>
      <p> Copyright @ {cur_yr} </p>
    </footer>
  );
}

export default Footer;