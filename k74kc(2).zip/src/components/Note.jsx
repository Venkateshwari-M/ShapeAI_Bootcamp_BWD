import React from "react";

function Note() {
  return (
    <div className="note">
      <h1>
        <b> Life </b>
      </h1>
      <p>
        The purpose of our lives is to be happy - <i> Dalai Lama </i>
      </p>
      <p>
        The best way to get started is to quit talking and begin doing -
        <i> Walt Disney </i>
      </p>
      <p>
        You learn more from failure than from success - <i> Unknown </i>
      </p>
    </div>
  );
}

export default Note;
